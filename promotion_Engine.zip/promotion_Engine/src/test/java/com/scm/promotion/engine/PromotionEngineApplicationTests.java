package com.scm.promotion.engine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PromotionEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
